from SysStatCollector import *

import traceback,time

class bcolors:
	HEADER = '\033[95m'
	OKBLUE = '\033[94m'
	OKGREEN = '\033[92m'
	WARNING = '\033[93m'
	FAIL = '\033[91m'
	ENDC = '\033[0m'

if __name__ == "__main__":

	
	try:
			
		sysStat = SysStatCollector(global_collect_interval)
				
		while True:
#time$$ usage,idle,user,nice,system $$ memTotal,used,free,buffers,cached,swapTotal,swapFree $$ avgqu_sz,await,util
		
			generalInfo = sysStat.top()
			gt = generalInfo.split(',')[:16]
			gt[0] = time.strftime('%H:%M:%S',time.localtime(int(gt[0])))
			
			output = '''
	                  \033[95m  %s  \033[0m
	           
	
    \033[93m CPU \033[0m :   
          
          \033[92m Usage=%s,idle=%s, user=%s,nice=%s,system=%s \033[0m
    
    \033[93m Memory (size in KB) \033[0m: 
        
          \033[92m Total=%s,used=%s,free=%s,buffers=%s,cached=%s \033[0m
    
    \033[93m Swap   (size in KB) \033[0m:
       
          \033[92m Total=%s,free=%s \033[0m
    
    \033[93m DiskIO \033[0m: 
       
          \033[92m avgqu_sz=%s,await=%s,util=%s \033[0m
			
			'''% tuple(gt)
			
			
			# Clear the screen.
			print ('\x1b[H\x1b[2J')
			
			print (output)			
			
			time.sleep(global_collect_interval)
		
	except :		
		exStr = traceback.format_exc()   
		raise
		# logger.error ("Exception happens \n" + exStr)

