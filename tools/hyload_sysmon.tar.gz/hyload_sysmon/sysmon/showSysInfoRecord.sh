#!/bin/sh
ps -ef | grep SysInfoRecord.py| grep -v grep 
