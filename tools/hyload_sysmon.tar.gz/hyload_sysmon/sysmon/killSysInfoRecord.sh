#!/bin/sh
# kill  stats agent if it exists.
PROC_PID=`ps -ef | grep SysInfoRecord.py| grep -v grep |awk '{printf "%s ", $2}'`
for PID in $PROC_PID
do
  if kill -9 $PID
     then
        echo "Process SysInfoRecord($PID) was stopped at " `date`
     else
        echo "Process SysInfoRecord($PID) can not be stopped at " `date`
   fi
done
