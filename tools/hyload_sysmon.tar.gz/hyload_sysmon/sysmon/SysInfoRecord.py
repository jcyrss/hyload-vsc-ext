from SysStatCollector import *
import traceback



if __name__ == "__main__":

	
	try:
		
		endTimeLong = time.time() + global_monitor_duration
		
		curTime = time.strftime('%Y-%m-%d_%H%M%S',time.localtime())
		recFH = open(f'res--{curTime}.csv' , 'w')
		
		
		sysStat = SysStatCollector(global_collect_interval)

		
# 		recNumber = 0
		
		lastRecGeneralInfoTime   = 0
		

		
		while True:
			intCurTime = time.time()
			
			if intCurTime - lastRecGeneralInfoTime >= global_collect_interval:
				
				generalInfo = sysStat.top() +'\n'
				
				recFH.write(generalInfo)
				recFH.flush()
				
				lastRecGeneralInfoTime = intCurTime
			
				
			
				
			
			if intCurTime >  endTimeLong:
				print ('\n\n*************** Monitoring duration is over *****************\n')
				sys.exit()
				

			
			
			time.sleep(0.01)
		
	except :		
		exStr = traceback.format_exc()   
		logger.error ("Exception happens \n" + exStr)
		sys.exit()

