import paramiko
import os





# Connect to remote machine
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

print ("login to MI machine as root")
result = ssh.connect("192.168.200.148", username = "root", password = "sdfsdf")
print ()

#mkdir /testing/
cmdStr = '''mkdir /testing/'''
stdin, stdout, stderr = ssh.exec_command(cmdStr)

#copy file to remote machine
cmdStr = 'pscp -pw sdfsdf sysStatsCollector.py root@192.168.200.148:/testing/sysStatsCollector.py'
ret = os.system(cmdStr)
print (ret )



print ("check file /testing/sysStatsCollector.py")
cmdStr = '''ls /testing/sysStatsCollector.py'''
stdin, stdout, stderr = ssh.exec_command(cmdStr)
outRet = stdout.read()
errRet = stderr.read()

ssh.close()
if ("No such file or directory" in errRet) or ("sysStatsCollector.py" not in outRet):
    print ("copying failed!")
else:
    print ("done.")
    