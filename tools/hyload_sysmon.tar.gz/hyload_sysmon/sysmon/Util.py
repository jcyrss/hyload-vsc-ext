import time,sys,os,traceback
import Logger
logger =  Logger.Logger.getLogger("monitor.log",toScreen=False)



def printInTheSameLine(content):
	sys.stdout.write (chr(13))
	sys.stdout.write (content )

					

def changeConsecutiveSpaceToOne(inputStr):
	inputStr = inputStr.strip().replace("	"," ") #replace tab to space
	while inputStr.find("  ") >= 0: #if 2 consecutive space char found, change to one char
		inputStr = inputStr.replace("  "," ")

	return inputStr
			


def getProcessesJiffies(processTable):

	ProcessesJiffiesTable = {}
	try:
		for procname,pid in processTable.items():
			filePath = "/proc/"+pid+"/stat"
			if not os.path.isfile(filePath):
				logger.warning( procname+" pid "+str(pid)+" does not exists, maybe that process has been killed!")
				continue
			
			try:	
				statFh = open(filePath)
				line = statFh.readline()
				statFh.close()
			except:
				continue
			
			ProcessesJiffiesTable[procname] = line

		for procname,line in ProcessesJiffiesTable.items():
			items = line.split(' ')
			cutime = int(items[13])
			cstime = int(items[14])
			ProcessesJiffiesTable[procname] = cutime + cstime
			
			
			
			
		return ProcessesJiffiesTable
			
		
	except :
		exStr = traceback.format_exc()   
		logger.error ("Exception happens \n" + exStr)
		return {}


def getProcessMemInfo(name,pid):
	virtualMem = ""
	RssMem =""
	try:
		filePath = "/proc/"+pid+"/status"
		if not os.path.isfile(filePath):
			logger.warning(  name + " pid " + str(pid) + " does not exists, maybe it was killed!")
			return "",""
		
		statusFh = open(filePath)
		
		while True:
			line = statusFh.readline()
			# to the EOF
			if not line:
				break

			if line.startswith("VmSize:"):
				virtualMem = line
				
			elif line.startswith("VmRSS:"):
				RssMem = line
					
		
	except :
		exStr = traceback.format_exc()   
		logger.error ("Exception happens \n" + exStr)
		pass

	return virtualMem, RssMem

		

def getProcessIDByKeywords(searchWordList):
	result = []
	allList = os.listdir("/proc") 
	procList = []
	for one in allList:
		if one.isdigit():
			procList.append(one)

	
	for one in procList:
		cmdLineFile = "/proc/"+one+"/cmdline"
		if not os.path.isfile(cmdLineFile):
			continue
		
		try:
			f = open(cmdLineFile)
			firstLine = f.readline()
			f.close()
		except:
			continue
		
		found = True
		for searchWord in searchWordList:
			if not (firstLine.find(searchWord) >= 0):
				found = False ;	break
				
		if found: 
			result.append(one)
			
	return result

	

if __name__ == "__main__":
	
	print (getProcessIDByKeywords(["java","org.apache.catalina.startup.Bootstrap"]))


	
		
	
'''
PS_RESULT_FILE_NAME = "/.tmp_ps_result"
def getPIDFromPsResultFile():
	try:
		fh = open(PS_RESULT_FILE_NAME)
		line = fh.readline()
		fh.close()
		
		#process ID is at coloumn #2
		firstSpacePos = line.find(" ")	
		line = line[firstSpacePos:]
		
		idx1 = 0
		for ch in line:
			if ch != ' ':
				break
			idx1 += 1
		
		idx2 = idx1
		for ch in line[idx1:]:
			if ch == ' ':
				break
			idx2 += 1
			
		processID = line[idx1:idx2]
		return processID
		
	except :
		return False	
'''
