
global_monitor_duration = 3600*24*100 # in seconds

global_collect_interval = 1 #in seconds









