
from monitorCfg import *

from Util import *
import traceback

import subprocess
import sys
import string
import re,time

import glob
logger =  Logger.Logger.getLogger("monitor.log",toScreen=False)






MSG_HEAD = "{"
MSG_END = "}"
SEPARATOR_LEVEL_1 = "$$$$$"
SEPARATOR_LEVEL_2 = "####"
SEPARATOR_LEVEL_3 = "|||"
SEPARATOR_LEVEL_4 = "**"

CPU_STAT = "CPU_STAT"
MEMORY_STAT = "MEMORY_STAT"
NETIF_STAT = "NETIF_STAT"
VFS_STAT = "VFS_STAT"
DISKIO_STAT = "DISKIO_STAT"
JVM_STAT = "JVM_STAT"
PROC_STAT = "PROC_STAT"
TIMESTAMP = "TIMESTAMP"


from os.path import join as joinpath
from os.path import exists





class SysStatCollector:

    def __init__(self, host='', port=50000,interval=1):

        self.interval = interval

        self.previousCpuJiffies = self.getJiffies()
        
        self.currentCpuJiffies = None

        self.diskFileList = []

        self.detectDiskControllerType()

        self.previousDiskInfo = self.getDiskIo()
        self.currentDiskInfo = None

        
        time.sleep(interval)

    def detectDiskControllerType(self):
        sdList = glob.glob("/sys/block/sd*")
        vdList = glob.glob("/sys/block/vd*")

        self.diskFileList = [one+'/stat' for one in sdList+vdList]


    def getJiffies(self):
        
        f = open('/proc/stat', 'r')
        line = f.readline() #cpu  1326431 12563 977888 17226852 86915 1834 5201 0
        f.close()


        #delete header
        line = line.replace("cpu","")
        line = line.strip()

        stat = line.split(' ')

        cpuJiffies = [int(i) for i in stat] #
        return cpuJiffies



    def get_cpuinfo(self):	

        self.currentCpuJiffies = self.getJiffies()

        #**** cpu utilization calculate ******
        cpuUtilization = []
        for i in range(len(self.currentCpuJiffies)):
            cpuUtilization.append(self.currentCpuJiffies[i] - self.previousCpuJiffies[i])

        user  = cpuUtilization[0]
        nice  = cpuUtilization[1]
        system  = cpuUtilization[2]
        idle  = cpuUtilization[3]
        iowait  = cpuUtilization[4]
        hardirq  = cpuUtilization[5]
        softirq  = cpuUtilization[6]

# 		#for old version redhat, just 7 items
# 		if len(cpuUtilization) == 7:
# 			pass
# 		#for new version redhat, 8 items
# 		elif len(cpuUtilization) == 8:
# 			stealtime = cpuUtilization[7]
# 		else:
# 			logger.info( "Error! the /proc/stat format is not supported!")
# 			return ""



        total = 0.01*sum(cpuUtilization)
#		info = CPU_STAT + SEPARATOR_LEVEL_2
        str_usage = '%.1f' % (100 - idle/total) + "%"
        str_idle  = '%.1f' % (idle/total) + "%"
        str_user  = '%.1f' % (user/total) + "%"
        str_nice  = '%.1f' % (nice/total) + "%"
        str_system = '%.1f' % (system/total) + "%"




        #***** update	previous cpu utilization	*********
        self.previousCpuJiffies = self.currentCpuJiffies


        return "%s,%s,%s,%s,%s" % (str_usage,str_idle,str_user,str_nice,str_system) 


    def get_meminfo(self):
        f = open('/proc/meminfo', 'r')

        while True:
            line = f.readline()
            # to the EOF
            if not line:
                break

            line = line.replace(' ','').replace('kB',' ')
            line = line.split(':')
            if line[0] == 'MemTotal': MemTotal    = int(line[1])
            elif line[0] == 'MemFree': MemFree     = int(line[1])
            elif line[0] == 'Buffers': Buffers = int(line[1])
            elif line[0] == 'Cached': Cached = int(line[1])
            elif line[0] == 'SwapTotal': SwapTotal = int(line[1])
            elif line[0] == 'SwapFree': SwapFree = int(line[1])

        f.close()

#		info = MEMORY_STAT + SEPARATOR_LEVEL_2

        memTotal = '%d' % (MemTotal) 	
        used = '%.1f' % (100 - 100.0*(MemFree+Buffers+Cached)/MemTotal) + "%"
        free = '%.1f' % (MemFree*100.0/MemTotal) + "%"
        buffers = '%.1f' % (Buffers*100.0/MemTotal) + "%"
        cached = '%.1f' % (Cached*100.0/MemTotal) + "%"
        swapTotal = '%d' % (SwapTotal) 
        swapFree = '%d' % (SwapFree) 

        return "%s,%s,%s,%s,%s,%s,%s" % (memTotal,used,free,buffers,cached,swapTotal,swapFree) 




    def getDiskIo(self):

        allDiskIO =  [0] * 11
        if len(self.diskFileList) == 0:
            return allDiskIO

        for diskFile in self.diskFileList:
            f = open(diskFile, 'r')
            line = f.readline() #cpu  1326431 12563 977888 17226852 86915 1834 5201 0
            f.close()


            line = changeConsecutiveSpaceToOne(line)

            stat = line.split(' ')

            diskIo = [int(i) for i in stat] #

            for idx in range(11):
                allDiskIO[idx]  += diskIo[idx]

        return allDiskIO

    def get_ioStat(self):
        ##  see introduce on http://blogold.chinaunix.net/u/27493/showart_498055.html

#         if self.previousDiskInfo == None:
#             self.previousDiskInfo = self.getDiskIo()
#             time.sleep(self.interval)

        self.currentDiskInfo = self.getDiskIo()


        #**** disk IO calculate ******
        diskUtilization = []
        for i in range(len(self.currentDiskInfo)):
            diskUtilization.append(self.currentDiskInfo[i] - self.previousDiskInfo[i])

        readsIssued  = diskUtilization[0]            #r/s
        readsMerged  = diskUtilization[1]            #rrqm/s
        sectorsRead  = diskUtilization[2]            #rsec/s
        msOnReading  = diskUtilization[3]            #ruse
        writesCompleted  = diskUtilization[4]        #w/s
        writesMerged  = diskUtilization[5]           #wrqm/s
        sectorsWritten  = diskUtilization[6]         #wsec/s
        msOnWriting  = diskUtilization[7]            #wuse
        msOnIO  = diskUtilization[9]                 #use
        msOnIOWithWeight   = diskUtilization[10]     #aveq


        avgqu_sz =  msOnIOWithWeight/1000.0              #avgqu-sz
        rwIssued = readsIssued + writesCompleted
        if rwIssued == 0:
            v_await = 0
            svctm = 0
        else:
            v_await = (msOnReading + msOnWriting)/rwIssued  #await
            svctm =  msOnIO/rwIssued                      #svctm
        spendOnIoPerSecond = msOnIO/10.0               #%util



        avgqu_sz = '%.1f' % (avgqu_sz) 
        v_await    = '%.1f' % (v_await) 
        util     = '%.1f' % (spendOnIoPerSecond) 


        #***** update	previous DISK IO utilization	*********
        self.previousDiskInfo = self.currentDiskInfo


        return "%s,%s,%s" % (avgqu_sz,v_await,util) 




    def get_time(self):
        return str(time.time()).split('.')[0]
#        return time.strftime('%Y-%b-%d %H:%M:%S',time.localtime())
#		return TIMESTAMP + SEPARATOR_LEVEL_2  + time.strftime('%Y-%b-%d+%H:%M:%S',time.localtime())




    def top(self):


#		totalInfo = MSG_HEAD
        totalInfo = ""

#		time, str_usage,str_idle,str_user,str_nice,str_system,  memTotal,used,free,buffers,cached,swapTotal,swapFree, avgqu_sz,await,util
        totalInfo += self.get_time()  + ','
        totalInfo += self.get_cpuinfo() + ','
        totalInfo += self.get_meminfo()  + ','
        totalInfo += self.get_ioStat() + ','

#		totalInfo += MSG_END


        return totalInfo


       
       
