import logging
import logging.handlers
import sys,os


class Logger:
    
    
    loggerMap = {}
    
    @staticmethod 
    def getLogger(loggerName,toFile=True, toScreen=True, level=20):   
        if loggerName not in Logger.loggerMap.keys():   
            
            logger = logging.getLogger(loggerName)
            
            if os.name == 'posix':
                fileHdlr = logging.handlers.RotatingFileHandler(loggerName, maxBytes=1024*1024*15, backupCount=5000)
            else:
                fileHdlr = logging.FileHandler(loggerName)
            
            
            try:
                streamHdlr = logging.StreamHandler(strm=sys.stdout)
            except:
                streamHdlr = logging.StreamHandler(stream=sys.stdout)
            
            formatter = logging.Formatter("%(asctime)s ] %(message)s")
            
            fileHdlr.setFormatter(formatter)
            streamHdlr.setFormatter(formatter)
            
            if toFile:
                logger.addHandler(fileHdlr)
                
            if toScreen:
                logger.addHandler(streamHdlr)
            
            logger.setLevel(level)
            
            Logger.loggerMap[loggerName] = logger
            
            return logger
    
    
        else:
            return Logger.loggerMap[loggerName]
    
    

    @staticmethod 
    def setLogLevel(loggerName,level):
        logger = logging.getLogger(loggerName)   
        
        logger.setLevel(level)